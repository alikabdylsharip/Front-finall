import React from "react";

function WorkoutCard({ workout, onDelete, onToggleComplete }) {
  // Деструктуризация согласно требованиям Code Quality 
  const { id, title, category, duration, calories, completed, date } = workout;

  // Исправление ошибки "Invalid Date"
  const formatDate = (dateValue) => {
    const d = new Date(dateValue);
    return d instanceof Date && !isNaN(d) 
      ? d.toLocaleDateString() 
      : "New Entry";
  };

  return (
    <div style={cardStyle(completed)}>
      <div style={contentWrapper}>
        <div style={headerRow}>
          <h3 style={titleStyle}>{title || "Untitled Workout"}</h3>
          <span style={categoryTag}>{category || "General"}</span>
        </div>

        <div style={detailsList}>
          <div style={detailItem}>
            <span style={iconStyle}>⏱</span> 
            <strong>{duration || 0}</strong> min
          </div>
          <div style={detailItem}>
            <span style={iconStyle}>🔥</span> 
            <strong>{calories || 0}</strong> kcal
          </div>
          <div style={detailItem}>
            <span style={iconStyle}>📅</span> 
            {formatDate(date)}
          </div>
        </div>
      </div>

      <div style={actionsWrapper}>
        <button 
          onClick={() => onToggleComplete(id)} 
          style={completed ? undoBtn : doneBtn}
        >
          {completed ? "✓ Done" : "Mark Done"}
        </button>
        <button 
          onClick={() => onDelete(id)} 
          style={deleteBtn}
        >
          Delete
        </button>
      </div>
    </div>
  );
}

// --- Стили для идеальной сетки и UX ---

const cardStyle = (completed) => ({
  background: "#ffffff",
  borderRadius: "24px",
  padding: "24px",
  display: "flex",
  flexDirection: "column",
  justifyContent: "space-between",
  minHeight: "300px", // Фиксирует высоту для ровности рядов
  boxShadow: completed ? "none" : "0 10px 30px rgba(0,0,0,0.04)",
  border: completed ? "2px solid #10b981" : "1px solid #f1f5f9",
  transition: "all 0.3s ease",
  opacity: completed ? 0.8 : 1,
  textAlign: "left",
  position: "relative"
});

const contentWrapper = { flex: 1 };

const headerRow = { 
  display: "flex", 
  justifyContent: "space-between", 
  alignItems: "flex-start", 
  marginBottom: "20px" 
};

const titleStyle = { 
  fontSize: "18px", 
  fontWeight: "800", 
  color: "#1e293b", 
  margin: 0, 
  lineHeight: "1.2" 
};

const categoryTag = { 
  background: "#f1f5f9", 
  padding: "4px 10px", 
  borderRadius: "8px", 
  fontSize: "10px", 
  fontWeight: "800", 
  color: "#64748b", 
  textTransform: "uppercase" 
};

const detailsList = { 
  display: "flex", 
  flexDirection: "column", 
  gap: "12px" 
};

const detailItem = { 
  fontSize: "14px", 
  color: "#475569", 
  display: "flex", 
  alignItems: "center" 
};

const iconStyle = { marginRight: "10px", fontSize: "16px" };

const actionsWrapper = { 
  display: "flex", 
  gap: "10px", 
  marginTop: "20px", 
  paddingTop: "15px", 
  borderTop: "1px solid #f1f5f9" 
};

const btnBase = { 
  flex: 1, 
  padding: "12px", 
  borderRadius: "12px", 
  border: "none", 
  fontWeight: "700", 
  cursor: "pointer", 
  fontSize: "13px", 
  transition: "0.2s" 
};

const doneBtn = { ...btnBase, background: "#2563eb", color: "#fff" };
const undoBtn = { ...btnBase, background: "#10b981", color: "#fff" };
const deleteBtn = { ...btnBase, background: "transparent", color: "#ef4444", border: "1px solid #fee2e2" };

export default WorkoutCard;