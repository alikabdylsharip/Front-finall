function SearchFilter({
    searchTerm,
    selectedCategory,
    sortOption,
    onSearchChange,
    onCategoryChange,
    onSortChange,
  }) {
    return (
      <section className="filter-section">
        <h2>Search, Filter, and Sort</h2>
  
        <div className="filter-controls">
          <input
            type="text"
            placeholder="Search workouts..."
            value={searchTerm}
            onChange={onSearchChange}
          />
  
          <select value={selectedCategory} onChange={onCategoryChange}>
            <option value="All">All Categories</option>
            <option value="Cardio">Cardio</option>
            <option value="Strength">Strength</option>
            <option value="Flexibility">Flexibility</option>
            <option value="Yoga">Yoga</option>
          </select>
  
          <select value={sortOption} onChange={onSortChange}>
            <option value="default">Default</option>
            <option value="duration">Sort by Duration</option>
            <option value="calories">Sort by Calories</option>
          </select>
        </div>
      </section>
    );
  }
  
  export default SearchFilter;