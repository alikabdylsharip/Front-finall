import React, { useState } from "react";

function UserStatus() {
  const [active, setActive] = useState(true);

  return (
    <div>
      <p>Status: {active ? "Active" : "Inactive"}</p>
      <button onClick={() => setActive(!active)}>
        Change Status
      </button>
    </div>
  );
}

export default UserStatus;