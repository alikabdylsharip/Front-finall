import React, { useState, useEffect, useMemo } from "react";
import WorkoutList from "./WorkoutList";
import Counter from "./Counter";
import ThemeToggle from "./ThemeToggle";
import UserStatus from "./UserStatus";
import WorkoutForm from "./WorkoutForm";
import SearchFilter from "./SearchFilter";


function MainContent() {
  const [workouts, setWorkouts] = useState([]);
  const [loading, setLoading] = useState(true); 
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [sortOption, setSortOption] = useState("default");

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 800)); 
      
      const savedData = localStorage.getItem("myWorkouts");
      if (savedData) {
        setWorkouts(JSON.parse(savedData));
      }
      setLoading(false);
    };
    fetchData();
  }, []);

  useEffect(() => {
    if (!loading) {
      localStorage.setItem("myWorkouts", JSON.stringify(workouts));
    }
  }, [workouts, loading]);

  const processedWorkouts = useMemo(() => {
    let result = workouts.filter((w) =>
      w.title.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (selectedCategory !== "All") {
      result = result.filter((w) => w.category === selectedCategory);
    }

    return [...result].sort((a, b) => {
      if (sortOption === "duration") return b.duration - a.duration;
      if (sortOption === "calories") return b.calories - a.calories;
      return 0;
    });
  }, [workouts, searchTerm, selectedCategory, sortOption]);

  const stats = useMemo(() => {
    const total = workouts.length;
    const completed = workouts.filter(w => w.completed).length;
    const calories = workouts.reduce((sum, w) => sum + (Number(w.calories) || 0), 0);
    return { total, completed, calories };
  }, [workouts]);

  const handleAddWorkout = (newWorkout) => {
    // Деструктуризация и добавление даты (Requirement 49)
    const workoutWithDate = { ...newWorkout, date: new Date().toISOString() };
    setWorkouts((prev) => [...prev, workoutWithDate]);
  };

  const handleDeleteWorkout = (id) => {
    if (window.confirm("Are you sure?")) {
      setWorkouts((prev) => prev.filter((w) => w.id !== id));
    }
  };

  const handleToggleComplete = (id) => {
    setWorkouts((prev) =>
      prev.map((w) => (w.id === id ? { ...w, completed: !w.completed } : w))
    );
  };

  if (loading) return <div className="loader">AI is analyzing your database... ⌛</div>;

  return (
    <main className="main" style={{ animation: "fadeIn 0.6s ease" }}>
      <header className="main-header">
        <h2>Train Smarter with AI</h2>
        <p className="subtitle">Optimize performance through data-driven insights.</p>
      </header>

      <WorkoutForm onAddWorkout={handleAddWorkout} />

      <SearchFilter
        searchTerm={searchTerm}
        selectedCategory={selectedCategory}
        sortOption={sortOption}
        onSearchChange={(e) => setSearchTerm(e.target.value)}
        onCategoryChange={(e) => setSelectedCategory(e.target.value)}
        onSortChange={(e) => setSortOption(e.target.value)}
      />

      <section className="stats-section">
        <h3>Workout Statistics</h3>
        <div className="stats-grid">
          <StatCard label="Total Workouts" value={stats.total} />
          <StatCard label="Completed" value={stats.completed} />
          <StatCard label="Total Calories" value={`${stats.calories} kcal`} />
        </div>
      </section>

      <WorkoutList
        workouts={processedWorkouts}
        onDelete={handleDeleteWorkout}
        onToggleComplete={handleToggleComplete}
      />

      <div className="interactive-section">
        <h3>AI Dashboard Controls</h3>
        <div className="controls-row">
          <Counter />
          <ThemeToggle />
          <UserStatus />
        </div>
      </div>
    </main>
  );
}

const StatCard = ({ label, value }) => (
  <div className="stat-card">
    <span className="stat-label">{label}</span>
    <h4>{value}</h4>
  </div>
);

export default MainContent;