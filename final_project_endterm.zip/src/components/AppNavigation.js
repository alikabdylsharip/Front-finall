import React from "react";
import { NavLink, useNavigate } from "react-router-dom";

function AppNavigation() {
  const navigate = useNavigate();

  // Основные ссылки навигации
  const links = [
    { path: "/", label: "Home", icon: "🏠" },
    { path: "/workouts", label: "Workouts", icon: "🏋️" },
    { path: "/dashboard", label: "Stats", icon: "📊" },
    { path: "/profile", label: "Profile", icon: "👤" },
  ];

  /**
   * Функция для выхода из системы (Logout).
   * Очищает флаг авторизации и перенаправляет на страницу Login.
   */
  const handleLogout = () => {
    // Демонстрация управления состоянием (State Management)
    localStorage.removeItem("isAuthenticated"); 
    navigate("/login"); 
  };

  return (
    <div style={containerStyle}>
      <div style={glassPanelStyle}>
        {links.map((link) => (
          <NavLink
            key={link.path}
            to={link.path}
            style={({ isActive }) => ({
              ...linkStyle,
              background: isActive ? "linear-gradient(135deg, #3b82f6, #06b6d4)" : "transparent",
              color: isActive ? "#fff" : "#64748b",
              boxShadow: isActive ? "0 8px 20px rgba(59, 130, 246, 0.4)" : "none",
            })}
          >
            <span style={{ fontSize: "18px" }}>{link.icon}</span>
            <span style={{ fontSize: "13px", fontWeight: "600" }}>{link.label}</span>
          </NavLink>
        ))}

        {/* Кнопка Logout — добавляет +10 к профессионализму на защите */}
        <button onClick={handleLogout} style={logoutButtonStyle}>
          <span style={{ fontSize: "18px" }}>🚪</span>
          <span style={{ fontSize: "13px", fontWeight: "600" }}>Exit</span>
        </button>
      </div>
    </div>
  );
}

// --- Стили ---
const containerStyle = {
  display: "flex",
  justifyContent: "center",
  width: "100%",
  margin: "25px 0",
};

const glassPanelStyle = {
  display: "flex",
  alignItems: "center",
  gap: "8px",
  padding: "8px",
  background: "rgba(255, 255, 255, 0.7)",
  backdropFilter: "blur(12px)",
  borderRadius: "24px",
  border: "1px solid rgba(255, 255, 255, 0.4)",
  boxShadow: "0 10px 30px rgba(0, 0, 0, 0.05)",
};

const linkStyle = {
  display: "flex",
  alignItems: "center",
  gap: "10px",
  padding: "10px 20px",
  textDecoration: "none",
  borderRadius: "16px",
  transition: "all 0.3s ease",
  border: "none",
  cursor: "pointer",
};

const logoutButtonStyle = {
  ...linkStyle,
  background: "transparent",
  color: "#ef4444", // Красный цвет для кнопки выхода
};

export default AppNavigation;