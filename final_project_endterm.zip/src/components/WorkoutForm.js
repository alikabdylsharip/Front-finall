import { useState } from "react";
function WorkoutForm({ onAddWorkout }) {
  const [formData, setFormData] = useState({
    title: "",
    category: "Cardio",
    duration: "",
    calories: "",
  });
  const [error, setError] = useState("");
  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    const { title, category, duration, calories } = formData;
    if (
      title.trim() === "" ||
      category.trim() === "" ||
      duration === "" ||
      calories === ""
    ) {
      setError("Please fill in all fields.");
      return;
    }
    if (Number(duration) <= 0 || Number(calories) <= 0) {
      setError("Duration and calories must be greater than 0.");
      return;
    }
    const newWorkout = {
      id: Date.now(),
      title: title.trim(),
      category,
      duration: Number(duration),
      calories: Number(calories),
      completed: false,
    };
    onAddWorkout(newWorkout);
    setFormData({
      title: "",
      category: "Cardio",
      duration: "",
      calories: "",
    });
    setError("");
  };
  return (
    <section className="form-section">
      <h2>Add New Workout</h2>
      <form className="workout-form" onSubmit={handleSubmit}>
        <input
          type="text"
          name="title"
          placeholder="Workout title"
          value={formData.title}
          onChange={handleChange}
        />
        <select
          name="category"
          value={formData.category}
          onChange={handleChange}

        >
          <option value="Cardio">Cardio</option>
          <option value="Strength">Strength</option>
          <option value="Flexibility">Flexibility</option>
          <option value="Yoga">Yoga</option>
        </select>
        <input
          type="number"
          name="duration"
          placeholder="Duration (minutes)"
          value={formData.duration}
          onChange={handleChange}
        />
        <input
          type="number"
          name="calories"
          placeholder="Calories burned"
          value={formData.calories}
          onChange={handleChange}
        />
        <button type="submit">Add Workout</button>
      </form>
      {error && <p className="error-message">{error}</p>}
    </section>
  );
}
export default WorkoutForm;