import React, { useState, useEffect } from "react";

function Counter() {
  const [count, setCount] = useState(() => {
    const saved = localStorage.getItem("workoutCount");
    return saved ? parseInt(saved, 10) : 0;
  });

  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");

  useEffect(() => {
    localStorage.setItem("workoutCount", count.toString());
  }, [count]);

  const handleAdd = async () => {
    setLoading(true);
    setStatus("Syncing...");

    await new Promise((resolve) => setTimeout(resolve, 800));

    setCount((prev) => prev + 1);
    setLoading(false);
    setStatus("Saved! ✨");
    setTimeout(() => setStatus(""), 2000);
  };

  const handleReset = () => {
    if (window.confirm("Are you sure you want to reset your progress?")) {
      setCount(0);
      setStatus("Reset successful 🗑️");
      setTimeout(() => setStatus(""), 2000);
    }
  };

  return (
    <div style={containerStyle}>
      <div style={headerStyle}>
        <span style={badgeStyle}>Season Progress</span>
        <h3 style={{ fontSize: "28px", margin: "10px 0" }}>{count}</h3>
        <p style={{ fontSize: "12px", color: "var(--text-soft)" }}>Total Workouts Completed</p>
      </div>

      
      <div style={{ height: "20px", marginBottom: "10px" }}>
        {status && <span style={statusStyle}>{status}</span>}
      </div>

      <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
        <button 
          onClick={handleAdd} 
          disabled={loading} 
          style={{ ...btnBase, background: "#2563eb", color: "#fff", flex: 2 }}
        >
          {loading ? "Processing..." : "Add Workout"}
        </button>

        <button 
          onClick={handleReset} 
          style={{ ...btnBase, background: "transparent", color: "#ef4444", border: "1px solid #fee2e2", flex: 1 }}
        >
          Reset
        </button>
      </div>
    </div>
  );
}

const containerStyle = {
  background: "var(--card-bg, #fff)",
  padding: "25px",
  borderRadius: "20px",
  boxShadow: "0 10px 30px rgba(0,0,0,0.05)",
  textAlign: "center",
  maxWidth: "300px",
  margin: "20px auto",
  animation: "fadeIn 0.5s ease"
};

const headerStyle = { marginBottom: "20px" };

const badgeStyle = {
  background: "#f1f5f9",
  color: "#64748b",
  padding: "4px 12px",
  borderRadius: "10px",
  fontSize: "10px",
  fontWeight: "800",
  textTransform: "uppercase"
};

const btnBase = {
  padding: "12px",
  border: "none",
  borderRadius: "12px",
  cursor: "pointer",
  fontWeight: "700",
  fontSize: "14px",
  transition: "0.3s"
};

const statusStyle = {
  fontSize: "12px",
  color: "#10b981",
  fontWeight: "600"
};

export default Counter;