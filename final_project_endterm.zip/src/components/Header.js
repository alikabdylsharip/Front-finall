import React from "react";

function Header() {
  return (
    <header className="header">
      AI FITNESS COACH
    </header>
  );
}

export default Header;