import React from "react";
import WorkoutCard from "./WorkoutCard";

function WorkoutList({ workouts, onDelete, onToggleComplete }) {
  if (workouts.length === 0) {
    return <p className="empty-message">No workouts found.</p>;
  }

  return (
    <div className="workout-section">
      {workouts.map((workout) => (
        <WorkoutCard
          key={workout.id}
          workout={workout}
          onDelete={onDelete}
          onToggleComplete={onToggleComplete}
        />
      ))}
    </div>
  );
}

export default WorkoutList;