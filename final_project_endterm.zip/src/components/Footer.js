import React from "react";

function Footer() {
  return (
    <footer className="footer">
      © 2026 AI Fitness Coach. All rights reserved.
    </footer>
  );
}

export default Footer;