import React, { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom"; 
import WorkoutCard from "../components/WorkoutCard";

function Workouts() {
  const [workouts, setWorkouts] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filter, setFilter] = useState("all"); 
  const [loading, setLoading] = useState(true); 
  const [statusMsg, setStatusMsg] = useState(""); 

 
  useEffect(() => {
    const loadWorkouts = async () => {
      setLoading(true);
      await new Promise((resolve) => setTimeout(resolve, 600)); 
      const saved = localStorage.getItem("myWorkouts");
      if (saved) {
        try {
          setWorkouts(JSON.parse(saved));
        } catch (e) {
          console.error("Critical error loading workouts", e);
        }
      }
      setLoading(false);
    };
    loadWorkouts();
  }, []);

  const filteredWorkouts = useMemo(() => {
    return workouts
      .filter((w) => {
        const matchesSearch = w.title.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesFilter = 
          filter === "all" || 
          (filter === "completed" && w.completed) || 
          (filter === "active" && !w.completed);
        return matchesSearch && matchesFilter;
      })
      .sort((a, b) => new Date(b.date) - new Date(a.date)); 
  }, [workouts, filter, searchQuery]);

  const showNotification = (msg) => {
    setStatusMsg(msg);
    setTimeout(() => setStatusMsg(""), 3000);
  };

  const saveAndSet = async (data, msg) => {
    localStorage.setItem("myWorkouts", JSON.stringify(data));
    setWorkouts(data);
    if (msg) showNotification(msg);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Permanent delete this log?")) {
      const updated = workouts.filter((w) => w.id !== id);
      await saveAndSet(updated, "Workout deleted successfully 🗑️");
    }
  };

  const handleToggle = (id) => {
    const updated = workouts.map((w) =>
      w.id === id ? { ...w, completed: !w.completed } : w
    );
    saveAndSet(updated, "Status updated! ✨");
  };

  if (loading) return <div className="main" style={centerStyle}>Analyzing your logs... 📡</div>;

  return (
    <div className="main" style={{ animation: "fadeIn 0.5s ease" }}>
      <div style={{ height: "40px", textAlign: "center" }}>
        {statusMsg && <div className="badge" style={successBadgeStyle}>{statusMsg}</div>}
      </div>

      <header style={headerWrapper}>
        <h2>My Performance Logs</h2>
        <Link to="/" className="cta-button" style={{ margin: 0 }}>+ New Entry</Link>
      </header>

      <div style={toolbarStyle}>
        <div style={{ flex: 2, position: 'relative' }}>
          <input 
            type="text" 
            placeholder="Search by title..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={inputStyle}
          />
        </div>
        
        <select value={filter} onChange={(e) => setFilter(e.target.value)} style={selectStyle}>
          <option value="all">All Activities</option>
          <option value="completed">Completed</option>
          <option value="active">In Progress</option>
        </select>
      </div>

      <div className="workout-section">
        {filteredWorkouts.length > 0 ? (
          filteredWorkouts.map((workout) => (
            <WorkoutCard 
              key={workout.id} 
              workout={workout} 
              onDelete={handleDelete}
              onToggleComplete={handleToggle}
            />
          ))
        ) : (
          <div style={emptyStateStyle}>
            <h3>No workouts found</h3>
            <p>Try adjusting your filters or start a new session!</p>
          </div>
        )}
      </div>
    </div>
  );
}

const headerWrapper = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "30px" };
const toolbarStyle = { display: "flex", gap: "15px", marginBottom: "30px", flexWrap: "wrap" };
const inputStyle = { width: "100%", padding: "12px 20px", borderRadius: "15px", border: "1px solid var(--card-border)", background: "var(--input-bg)", color: "var(--text-main)", outline: "none" };
const selectStyle = { padding: "12px", borderRadius: "15px", border: "1px solid var(--card-border)", background: "var(--input-bg)", color: "var(--text-main)", cursor: "pointer" };
const successBadgeStyle = { background: "#10b981", color: "white", padding: "5px 20px", borderRadius: "20px", fontSize: "14px", display: "inline-block" };
const emptyStateStyle = { textAlign: "center", padding: "60px 20px", background: "var(--card-bg)", borderRadius: "20px", opacity: 0.7 };
const centerStyle = { display: "flex", justifyContent: "center", alignItems: "center", height: "50vh" };

export default Workouts;