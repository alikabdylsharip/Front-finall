import React from "react";
import { NavLink, Link, Outlet } from "react-router-dom";

function DashboardLayout() {
  const menuItems = [
    { path: "/dashboard", label: "Overview", end: true },
    { path: "/dashboard/stats", label: "Stats" },
    { path: "/dashboard/settings", label: "Settings" },
  ];

  const getLinkClass = ({ isActive }) => 
    isActive ? "cta-button" : "workout-form button";

  return (
    <div className="main">
      <div style={{ 
        display: "flex", 
        justifyContent: "space-between", 
        alignItems: "center", 
        marginBottom: "40px",
        padding: "0 20px" 
      }}>
        <h1 style={{ margin: 0 }}>Control Panel</h1>
        
        <Link 
          to="/" 
          style={{ 
            textDecoration: 'none', 
            color: '#ff4b2b', 
            fontWeight: '600',
            fontSize: '14px',
            display: 'flex',
            alignItems: 'center',
            gap: '5px',
            padding: '8px 15px',
            borderRadius: '12px',
            background: 'rgba(255, 75, 43, 0.1)', 
            transition: 'all 0.2s ease'
          }}
          onMouseEnter={(e) => e.target.style.background = 'rgba(255, 75, 43, 0.2)'}
          onMouseLeave={(e) => e.target.style.background = 'rgba(255, 75, 43, 0.1)'}
        >
          <span>Logout</span> 
          <span style={{ fontSize: '18px' }}>→</span>
        </Link>
      </div>
      
      <nav style={{ 
        marginBottom: "30px", 
        display: "flex", 
        justifyContent: "center", 
        gap: "10px",
        background: 'rgba(255,255,255,0.4)', 
        padding: '10px',
        borderRadius: '20px',
        width: 'fit-content',
        margin: '0 auto 30px'
      }}>
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            end={item.end}
            className={getLinkClass}
            style={{ textDecoration: 'none', minWidth: '100px', textAlign: 'center' }}
          >
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="stats-section">
        <Outlet />
      </div>
    </div>
  );
}

export default DashboardLayout;