import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {
  const [credentials, setCredentials] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    await new Promise((resolve) => setTimeout(resolve, 1000));

    if (credentials.email === "admin@test.com" && credentials.password === "12345") {
      localStorage.setItem("isAuthenticated", "true");
      if (!localStorage.getItem("fitnessUser")) {
        localStorage.setItem("fitnessUser", JSON.stringify({ name: "Admin", goal: "Maintain" }));
      }
      navigate("/dashboard");
    } else {
      setError("Неверный email или пароль. (Подсказка: admin@test.com / 12345)");
      setLoading(false);
    }
  };

  return (
    <div className="main" style={{ maxWidth: "450px", margin: "80px auto" }}>
      <div className="form-section">
        <h2>Login to AI Fitness Coach</h2>
        <p style={{ color: "var(--text-soft)", marginBottom: "20px" }}>
          Please enter your credentials to continue.
        </p>
        
        <form onSubmit={handleLogin} className="workout-form" style={{ flexDirection: "column", gap: "15px" }}>
          <input
            type="email"
            placeholder="Email Address"
            required
            value={credentials.email}
            onChange={(e) => setCredentials({ ...credentials, email: e.target.value })}
          />
          <input
            type="password"
            placeholder="Password"
            required
            value={credentials.password}
            onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
          />
          <button type="submit" disabled={loading} style={{ width: "100%" }}>
            {loading ? "Authenticating..." : "Sign In"}
          </button>
        </form>
        
        {error && <p className="error-message" style={{ marginTop: "15px" }}>{error}</p>}
      </div>
    </div>
  );
}

export default Login;