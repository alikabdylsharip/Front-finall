import React from "react";
import { Link } from "react-router-dom";

function NotFound() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>404 Page</h1>
      <Link to="/">Back to Home</Link>
    </div>
  );
}

export default NotFound;