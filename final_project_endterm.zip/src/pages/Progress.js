import React, { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";

function Progress() {
  const [workouts, setWorkouts] = useState([]);

  useEffect(() => {
    const saved = localStorage.getItem("myWorkouts");
    if (saved) {
      try {
        setWorkouts(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse workouts", e);
      }
    }
  }, []);

  const stats = useMemo(() => {
    const total = workouts.length;
    const completed = workouts.filter(w => w.completed).length;
    const calories = workouts.reduce((sum, w) => sum + (Number(w.calories) || 0), 0);
    const minutes = workouts.reduce((sum, w) => sum + (Number(w.duration) || 0), 0);
    const rate = total > 0 ? Math.round((completed / total) * 100) : 0;
    const avgDuration = total > 0 ? Math.round(minutes / total) : 0;

    return { total, completed, calories, minutes, rate, avgDuration };
  }, [workouts]);

  return (
    <div className="main">
      <h2>Your Progress Achievements</h2>
      <p>Analyze your performance and stay motivated!</p>

      {stats.total === 0 ? (
        <div style={{ padding: "40px", textAlign: "center", opacity: 0.7 }}>
          <p>No workouts recorded yet. Start training to see your stats!</p>
        </div>
      ) : (
        <div className="stats-section">
          <div style={{ 
            width: "100%", 
            height: "10px", 
            background: "#eee", 
            borderRadius: "5px", 
            marginBottom: "30px",
            overflow: "hidden" 
          }}>
            <div style={{ 
              width: `${stats.rate}%`, 
              height: "100%", 
              background: "var(--accent-color, #4CAF50)", 
              transition: "width 0.5s ease-in-out" 
            }} />
          </div>

          <div className="stats-grid">
            <StatCard label="Completion Rate" value={`${stats.rate}%`} />
            <StatCard label="Total Burned" value={`${stats.calories} kcal`} />
            <StatCard label="Time Spent" value={`${stats.minutes} min`} />
          </div>

          <div style={{ marginTop: "40px", textAlign: "left", padding: "0 20px" }}>
            <h3>Insights:</h3>
            <ul style={{ color: "var(--text-soft)", fontSize: "18px", lineHeight: "2" }}>
              <li>🔥 You've burned a total of <strong>{stats.calories}</strong> calories.</li>
              <li>✅ You have successfully finished <strong>{stats.completed}</strong> workouts.</li>
              <li>⏱ Your average workout duration is <strong>{stats.avgDuration}</strong> minutes.</li>
            </ul>
          </div>
        </div>
      )}

      <Link to="/" className="cta-button" style={{ textDecoration: "none", marginTop: "20px", display: "inline-block" }}>
        Back to Dashboard
      </Link>
    </div>
  );
}

const StatCard = ({ label, value }) => (
  <div className="stat-card">
    <span className="stat-label">{label}</span>
    <h4>{value}</h4>
  </div>
);

export default Progress;