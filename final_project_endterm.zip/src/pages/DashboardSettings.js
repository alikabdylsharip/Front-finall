import React, { useState } from "react";

function DashboardSettings({ isDark, setIsDark }) {
  const [status, setStatus] = useState({ message: "", type: "" });
  const [loading, setLoading] = useState(false);

  const showToast = (message, type = "success") => {
    setStatus({ message, type });
    setTimeout(() => setStatus({ message: "", type: "" }), 3000);
  };

  const handleExport = async () => {
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    
    try {
      const data = localStorage.getItem("myWorkouts") || "[]";
      const blob = new Blob([data], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `backup-${new Date().toLocaleDateString()}.json`;
      link.click();
      showToast("Data exported successfully! 📥");
    } catch (e) {
      showToast("Export failed", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    if (window.confirm("Permanent delete all workout logs? [cite: 45]")) {
      localStorage.removeItem("myWorkouts");
      showToast("History wiped clean 🗑️", "error");
      window.dispatchEvent(new Event('storage'));
    }
  };

  return (
    <div style={containerStyle}>
      <header style={{ textAlign: 'center', marginBottom: '30px' }}>
        <h2 style={{ fontSize: '28px' }}>System Preferences</h2>
        <p style={{ opacity: 0.6 }}>Manage your local database and interface</p>
      </header>

      <div style={{ height: '50px', marginBottom: '10px' }}>
        {status.message && (
          <div style={{ 
            ...toastStyle, 
            background: status.type === "success" ? "#10b981" : "#ef4444" 
          }}>
            {status.message}
          </div>
        )}
      </div>

      <div style={layoutStyle}>
        <section style={cardStyle}>
          <h3 style={cardTitle}>Appearance</h3>
          <div style={rowStyle}>
            <div>
              <strong>Dark Interface</strong>
              <p style={subText}>Switch between light and dark themes</p>
            </div>
            <button 
              onClick={() => setIsDark(!isDark)} 
              style={{ ...toggleBtn, background: isDark ? '#3b82f6' : '#cbd5e1' }}
            >
              {isDark ? "ON" : "OFF"}
            </button>
          </div>
        </section>

        <section style={cardStyle}>
          <h3 style={cardTitle}>Data Storage</h3>
          <div style={{ display: 'flex', gap: '10px', marginTop: '15px' }}>
            <button 
              onClick={handleExport} 
              disabled={loading}
              style={{ ...actionBtn, flex: 2, background: 'var(--accent-color, #2563eb)' }}
            >
              {loading ? "Processing..." : "Create Backup (.json)"}
            </button>
            <button 
              onClick={handleClear} 
              style={{ ...actionBtn, flex: 1, background: '#fee2e2', color: '#dc2626' }}
            >
              Wipe
            </button>
          </div>
        </section>

        <footer style={versionStyle}>
          Build Version: 2.0.4-stable | Engine: React 18+
        </footer>
      </div>
    </div>
  );
}

const containerStyle = { maxWidth: '700px', margin: '0 auto', animation: 'fadeIn 0.4s ease' };
const layoutStyle = { display: 'flex', flexDirection: 'column', gap: '20px' };
const cardStyle = { background: 'var(--card-bg, #fff)', padding: '24px', borderRadius: '20px', border: '1px solid var(--card-border, #eee)', boxShadow: '0 4px 20px rgba(0,0,0,0.03)' };
const cardTitle = { fontSize: '18px', fontWeight: '700', marginBottom: '15px', color: 'var(--text-main)' };
const rowStyle = { display: 'flex', justifyContent: 'space-between', alignItems: 'center' };
const subText = { fontSize: '12px', opacity: 0.6, margin: '4px 0 0 0' };
const toastStyle = { padding: '10px 25px', color: '#fff', borderRadius: '30px', fontSize: '14px', fontWeight: '600', textAlign: 'center', margin: '0 auto', width: 'fit-content', boxShadow: '0 8px 15px rgba(0,0,0,0.1)' };
const actionBtn = { padding: '12px', border: 'none', borderRadius: '12px', cursor: 'pointer', fontWeight: '600', transition: '0.3s', color: '#fff' };
const toggleBtn = { width: '60px', padding: '8px', border: 'none', borderRadius: '20px', cursor: 'pointer', color: '#fff', fontWeight: '800', transition: '0.3s' };
const versionStyle = { textAlign: 'center', fontSize: '11px', opacity: 0.4, marginTop: '20px', letterSpacing: '1px' };

export default DashboardSettings;