import React, { useState, useEffect, useMemo } from "react";

function DashboardStats() {
  const [workouts, setWorkouts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 600));
      
      try {
        const data = localStorage.getItem("myWorkouts");
        setWorkouts(data ? JSON.parse(data) : []);
      } catch (e) {
        setWorkouts([]);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const calculatedData = useMemo(() => {
    if (!workouts.length) return null;

    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const counts = {};
    let totalCals = 0;
    let totalMins = 0;
    let maxCal = 0;
    let maxDur = 0;

    workouts.forEach(({ calories, duration, date }) => {
      const cal = Number(calories) || 0;
      const dur = Number(duration) || 0;
      
      totalCals += cal;
      totalMins += dur;
      if (cal > maxCal) maxCal = cal;
      if (dur > maxDur) maxDur = dur;

      const d = new Date(date);
      if (!isNaN(d)) {
        const name = days[d.getDay()];
        counts[name] = (counts[name] || 0) + 1;
      }
    });

    const favoriteDay = Object.keys(counts).length 
      ? Object.keys(counts).reduce((a, b) => (counts[a] > counts[b] ? a : b)) 
      : "N/A";

    const goalPercent = Math.min((totalCals / 10000) * 100, 100);

    return { favoriteDay, totalCals, totalMins, maxCal, maxDur, goalPercent };
  }, [workouts]);

  if (loading) return <div className="main">Calculating metrics... 📊</div>;

  if (!workouts.length) {
    return (
      <div className="empty-message">
        <h3>No analytics yet</h3>
        <p>Complete a workout to unlock deep insights! 🚀</p>
      </div>
    );
  }

  const { favoriteDay, totalCals, totalMins, maxCal, maxDur, goalPercent } = calculatedData;

  return (
    <div className="stats-section" style={{ textAlign: 'left' }}>
      <h2>Deep Analytics</h2>
      
      <div style={{ marginBottom: '30px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
          <span style={{ fontSize: '14px', fontWeight: '600' }}>Monthly Calories Goal</span>
          <span style={{ fontSize: '14px' }}>{goalPercent.toFixed(0)}%</span>
        </div>
        <div style={progressContainer}>
          <div style={{ ...progressFill, width: `${goalPercent}%` }} />
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <span className="stat-label">Intensity</span>
          <h4>{(totalCals / (totalMins || 1)).toFixed(1)} <small>kcal/m</small></h4>
        </div>
        <div className="stat-card">
          <span className="stat-label">Best Day</span>
          <h4>{favoriteDay}</h4>
        </div>
        <div className="stat-card">
          <span className="stat-label">Workouts</span>
          <h4>{workouts.length}</h4>
        </div>
      </div>

      <div className="interactive-section" style={{ marginTop: '20px', padding: '20px' }}>
        <h3 style={{ fontSize: '20px' }}>Personal Best</h3>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--card-border)' }}>
          <span>🔥 Highest Burn:</span>
          <strong>{maxCal} kcal</strong>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0' }}>
          <span>⏱ Longest Session:</span>
          <strong>{maxDur} min</strong>
        </div>
      </div>
    </div>
  );
}

const progressContainer = { height: '10px', background: 'var(--input-bg)', borderRadius: '5px', overflow: 'hidden' };
const progressFill = { height: '100%', background: 'linear-gradient(90deg, #2563eb, #06b6d4)', transition: 'width 1s ease' };

export default DashboardStats;