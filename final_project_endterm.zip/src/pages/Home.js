import React from "react";
import Header from "../components/Header";
import MainContent from "../components/MainContent";
import Footer from "../components/Footer";
import AppNavigation from "../components/AppNavigation"; 

function Home() {
  return (
    <div className="home-page" style={{ animation: "fadeIn 0.8s ease-in" }}>
      <Header />

      <AppNavigation />

      <main>
        <MainContent />
      </main>

      <Footer />
    </div>
  );
}

export default Home;