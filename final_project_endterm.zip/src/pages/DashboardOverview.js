import React, { useState, useEffect, useMemo } from "react";

function DashboardOverview() {
  const [workouts, setWorkouts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadWorkouts = async () => {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const saved = JSON.parse(localStorage.getItem("myWorkouts") || "[]");
      setWorkouts(saved);
      setLoading(false);
    };

    loadWorkouts();
  }, []);

  const analytics = useMemo(() => {
    if (workouts.length === 0) return null;

    const totalCalories = workouts.reduce((sum, w) => sum + (Number(w.calories) || 0), 0);
    const avgDuration = workouts.reduce((sum, w) => sum + (Number(w.duration) || 0), 0) / workouts.length;
    
    const categories = workouts.map(w => w.category);
    const topCategory = categories.sort((a, b) =>
      categories.filter(v => v === a).length - categories.filter(v => v === b).length
    ).pop();

    const recentWorkouts = workouts.slice(-3);
    const energyLevel = Math.min(recentWorkouts.length * 33.3, 100);

    return { totalCalories, avgDuration, topCategory, energyLevel };
  }, [workouts]);

  if (loading) return <div className="empty-message">Analyzing your progress... 📡</div>;

  return (
    <div style={{ animation: 'fadeIn 0.5s ease' }}>
      <header style={{ textAlign: 'center', marginBottom: '30px' }}>
        <h2 style={{ fontSize: '28px' }}>Performance Insights</h2>
        <div style={energyBarStyle}>
          <div style={{ 
            ...energyProgressStyle, 
            width: `${analytics?.energyLevel || 0}%`,
            background: analytics?.energyLevel > 50 ? 'var(--success)' : '#f39c12'
          }} />
          <span style={energyLabelStyle}>Energy Level: {analytics?.energyLevel.toFixed(0) || 0}%</span>
        </div>
      </header>

      <div className="stats-grid" style={gridStyle}>
        {/* Карточка 1: Общий объем */}
        <div className="stat-card">
          <span className="stat-label">🔥 Total Burned</span>
          <h4>{analytics?.totalCalories || 0} <small>kcal</small></h4>
          <p style={subTextStyle}>Across {workouts.length} sessions</p>
        </div>

        {/* Карточка 2: Интенсивность */}
        <div className="stat-card">
          <span className="stat-label">⏱ Avg. Duration</span>
          <h4>{analytics?.avgDuration.toFixed(1) || 0} <small>min</small></h4>
          <p style={subTextStyle}>Per workout session</p>
        </div>

        <div className="stat-card">
          <span className="stat-label">🏆 Top Category</span>
          <h4>{analytics?.topCategory || "N/A"}</h4>
          <p style={subTextStyle}>Your primary focus</p>
        </div>
      </div>

      <div style={insightBoxStyle}>
        <h4>🤖 AI Coach Insight:</h4>
        <p>
          {workouts.length === 0 
            ? "Your journey starts with the first log. Ready to push your limits?"
            : analytics.energyLevel < 50 
              ? "Your activity has dropped. A quick 15-min session could boost your energy!" 
              : `Great consistency! You've burned ${analytics.totalCalories} kcal so far. Keep dominating ${analytics.topCategory}!`}
        </p>
      </div>
    </div>
  );
}

const gridStyle = { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px' };
const subTextStyle = { fontSize: '12px', color: 'var(--text-soft)', marginTop: '5px' };
const energyBarStyle = { height: '24px', background: 'var(--input-bg)', borderRadius: '12px', position: 'relative', overflow: 'hidden', marginTop: '10px' };
const energyProgressStyle = { height: '100%', transition: 'width 1s ease-in-out' };
const energyLabelStyle = { position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', fontSize: '11px', fontWeight: '700', color: '#fff', textShadow: '1px 1px 2px rgba(0,0,0,0.5)' };
const insightBoxStyle = { marginTop: '40px', padding: '25px', borderRadius: '20px', background: 'var(--card-bg)', border: '1px solid var(--card-border)', textAlign: 'left' };

export default DashboardOverview;