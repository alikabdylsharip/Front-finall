import React, { useState, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";

function Profile() {
  const [user, setUser] = useState({
    name: "User",
    goal: "Lose weight",
    joinedDate: new Date().toLocaleDateString(),
    level: "Beginner"
  });

  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState("");
  const calculateLevel = useCallback(() => {
    const workoutsCount = JSON.parse(localStorage.getItem("myWorkouts") || "[]").length;
    if (workoutsCount > 50) return "Pro";
    if (workoutsCount > 10) return "Athlete";
    return "Beginner";
  }, []);

  useEffect(() => {
    const savedUser = localStorage.getItem("fitnessUser");
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setUser({ ...parsedUser, level: calculateLevel() });
    }
  }, [calculateLevel]);

  const handleSave = async (updatedData) => {
    setIsSaving(true);
    setMessage("");

    await new Promise((resolve) => setTimeout(resolve, 800));

    localStorage.setItem("fitnessUser", JSON.stringify(updatedData));
    setIsSaving(false);
    setMessage("Profile updated successfully! ✨");
    setTimeout(() => setMessage(""), 3000);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    const updatedUser = { ...user, [name]: value };
    setUser(updatedUser);
    
    handleSave(updatedUser);
  };

  return (
    <div className="main" style={containerStyle}>
      <header style={{ textAlign: "center", marginBottom: "30px" }}>
        <div style={avatarStyle}>
          {user.name ? user.name.charAt(0).toUpperCase() : "U"}
        </div>
        <h1 style={{ margin: "10px 0" }}>{user.name}'s Profile</h1>
        <span style={badgeStyle}>{user.level}</span>
      </header>

      <div className="workout-form" style={cardStyle}>
        <div style={{ height: "20px", textAlign: "center", marginBottom: "10px" }}>
          {isSaving && <span style={{ color: "#3b82f6", fontSize: "12px" }}>Syncing with cloud... ☁️</span>}
          {message && <span style={{ color: "#10b981", fontSize: "12px", fontWeight: "bold" }}>{message}</span>}
        </div>

        <div style={inputGroupStyle}>
          <label style={labelStyle}>Athlete Name</label>
          <input 
            name="name" 
            value={user.name} 
            onChange={handleChange} 
            style={inputStyle}
            placeholder="Enter your name"
          />
        </div>
        
        <div style={inputGroupStyle}>
          <label style={labelStyle}>Primary Fitness Goal</label>
          <select 
            name="goal" 
            value={user.goal} 
            onChange={handleChange} 
            style={inputStyle}
          >
            <option value="Lose weight">🔥 Lose weight</option>
            <option value="Gain muscle">💪 Gain muscle</option>
            <option value="Endurance">🏃‍♂️ Endurance</option>
            <option value="Flexibility">🧘 Flexibility</option>
          </select>
        </div>

        <div style={footerTextStyle}>
          Member since: {user.joinedDate}
        </div>
      </div>

      <div style={{ marginTop: "30px", textAlign: "center" }}>
        <Link to="/" className="cta-button" style={backBtnStyle}>
          ← Back to Dashboard
        </Link>
      </div>
    </div>
  );
}

const containerStyle = { maxWidth: "600px", margin: "0 auto", animation: "fadeIn 0.5s ease" };
const cardStyle = { 
  background: "var(--card-bg, #fff)", 
  padding: "30px", 
  borderRadius: "24px", 
  boxShadow: "0 10px 40px rgba(0,0,0,0.06)",
  border: "1px solid var(--card-border, #eee)"
};
const avatarStyle = {
  width: "90px", height: "90px",
  background: "linear-gradient(135deg, #3b82f6, #8b5cf6)",
  color: "white", borderRadius: "50%",
  display: "flex", alignItems: "center", justifyContent: "center",
  fontSize: "36px", fontWeight: "bold", margin: "0 auto",
  boxShadow: "0 8px 20px rgba(59, 130, 246, 0.3)"
};
const badgeStyle = { background: "#dbeafe", color: "#1e40af", padding: "6px 16px", borderRadius: "20px", fontSize: "12px", fontWeight: "800" };
const inputGroupStyle = { display: "flex", flexDirection: "column", textAlign: "left", gap: "8px", marginBottom: "15px" };
const labelStyle = { fontSize: "13px", fontWeight: "700", color: "var(--text-soft)" };
const inputStyle = { padding: "14px", borderRadius: "12px", border: "1px solid var(--card-border, #ddd)", fontSize: "16px", background: "var(--input-bg, #fff)", color: "var(--text-main)" };
const footerTextStyle = { marginTop: "20px", fontSize: "11px", color: "#94a3b8", textAlign: "center", letterSpacing: "1px" };
const backBtnStyle = { textDecoration: "none", display: "inline-block", padding: "12px 25px", borderRadius: "15px", fontWeight: "600" };

export default Profile;