AI Fitness Coach Project

Project Overview
AI Fitness Coach** is a modern React-based Single Page Application (SPA) designed to help users manage their workouts and track fitness progress. 
This project focuses on a clean UI, smooth user experience, and robust technical implementation using React best practices.

The app allows users to create, filter, and track workouts while maintaining data across sessions.

 Key Features & Implementation
]I have implemented the following core requirements specified in the project assignment[cite: 42, 43]:

uthentication Flow:** A mock login system (admin@test.com / 12345) that demonstrates how to handle user credentials and session states[cite: 58].
Using `react-router-dom` v6, I secured routes like `/dashboard`, `/workouts`, and `/profile`. 
Unauthorized users are automatically redirected to the login page.
State Management & Persistence:
    Data Persistence: All workout logs and profile settings are synced with `localStorage`, so data is never lost on page refresh.
    Global Theme:A dark/light mode toggle is implemented using global state.
Advanced React Hooks:
    `useMemo`: Used to optimize performance when calculating statistics and filtering large workout lists
    `useCallback`: Implemented to stabilize functions and prevent unnecessary component re-renders
    `useEffect`: Used for asynchronous data simulation and syncing state with local storage
Full CRUD Functionality:** Users can Create (add workouts), Read (view lists), Update (toggle completion status), and Delete records
Responsive Glassmorphism UI:The interface is fully responsive, looking great on both desktop and mobile devices

Tech Stack
Library: React 18+
Routing: React Router v6 (Nested Routes & Protected Routes)
Styling: CSS3 (Custom Variables & Animations)
Data: Browser LocalStorage API

Setup & Installation
To run this project locally, follow these steps:

1.  Clone the repository.
2.  Install dependencies:
    ```
    npm install
    ```
3.  Start the development server:
    ```
    npm start
    ```
4.  Open [http://localhost:3000](http://localhost:3000) in your browser.

Login for Defense
To test the protected routes during the defense, please use:
Email:`admin@test.com`
assword:`12345`

 SPA Theory (Quick Summary)
What is an SPA? It’s a web app that loads once. Updates happen dynamically via JavaScript without refreshing the whole page, making it feel like a desktop app.
Virtual DOM:React’s way of mapping the UI. It compares the "virtual" version to the "real" one and only updates the parts that actually changed, which saves a lot of performance.
Component Architecture: I built this app using independent, reusable blocks (components).
